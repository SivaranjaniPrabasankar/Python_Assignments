# Sivaranjani A20436206
# 11th July 2019
# ITMD-571 Lab-5 File Processing


import Sivaranjani_Lab5_ITMD513_Func

function_file = Sivaranjani_Lab5_ITMD513_Func


def main():
    print('**' * 50)
    print(' ' * 25, "Employee Operations")
    print('**' * 50)
    choice = function_file.menu()
    print(choice)
    while choice != 6:
        if choice == 1:
            function_file.print_all()
            choice = function_file.menu()

        elif choice == 2:
            find_fname = input('Please enter Employee First name to search')
            find_lname = input('Please enter Employee Last name to search')
            find_emp = find_fname + " " + find_lname
            function_file.print_emp(find_emp)
            choice = function_file.menu()

        elif choice == 3:
            function_file.add_emp()
            choice = function_file.menu()

        elif choice == 4:
            del_fame = input('Please enter Employee First name to delete')
            del_lname = input('Please enter Employee Last name to delete')
            del_emp = del_fame + " " + del_lname
            function_file.delete_emp(del_emp)
            choice = function_file.menu()

        elif choice == 5:
            mod_fname = input('Please enter Employee First name to modify')
            mod_lname = input('Please enter Employee Last name to modify')
            mod_emp = mod_fname + " " + mod_lname
            function_file.modify_emp(mod_emp)
            choice = function_file.menu()

    function_file.exit_app()


if __name__ == "__main__":
    main()
