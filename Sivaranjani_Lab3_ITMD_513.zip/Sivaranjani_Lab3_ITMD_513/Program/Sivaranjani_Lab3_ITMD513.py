import datetime

# Sivaranjani A20436206
# 25th June 2019
# ITMD-571 Lab-3 Loan Calculation

# declare variable as a float type to calculate Loan
loanAmount = 0.0
numberOfYears = 0
annualInterest = 0.0
monthlyPayment = 0.0
monthlyInterestRate = 0.0
interestAmount = 0.0
oldInterest = 0.0
principle = 0.0
totalInterestPaid, totalPrinciplePaid, totalPayment = 0.0, 0.0, 0.0

# Getting input from user
loanAmount = float(input('Please enter Loan amount : '))
numberOfYears = int(input('Please enter numberOfYears :'))
annualInterest = float(input('Please enter Annual interest rate : '))
monthlyInterestRate = annualInterest / (12 * 100)
monthlyPayment = (loanAmount * monthlyInterestRate * (1 + monthlyInterestRate) ** 12) / (
        ((1 + monthlyInterestRate) ** 12) - 1)

print('**' * 50)
start = 1
stop = 12
print("MonthlyPayment \t ", format(monthlyPayment, '.2f'))
print('--' * 20, "\n Loan Amortization Table \n", '--' * 20)
print("Month \t", end=" ")
print("InterestAmount \t", end=" ")
print("Principle \t    ", end=" ")
print("Balance \t ")

# Calculate & display loan detail from using user input

for count in range(start, stop + 1):
    oldInterest = interestAmount
    interestAmount = monthlyInterestRate * loanAmount
    if count == 1:
        principle = principle + (monthlyPayment-interestAmount)
    else:
        principle = principle + (oldInterest-interestAmount)

    loanAmount = loanAmount - principle
    totalInterestPaid = totalInterestPaid + interestAmount
    totalPrinciplePaid = totalPrinciplePaid + principle

    print(count, "\t   \t", end=" ")
    print(format(interestAmount, '.2f'), "\t   \t \t  \t", end=" ")
    print(format(principle, '.2f'), "\t   \t", end=" ")
    print(format(loanAmount, '.2f'))

totalPayment = totalInterestPaid + totalPrinciplePaid

# Calculate & display loan summary
print('--' * 20, "\n Loan Amortization Summary\n", '--' * 20)
print("Total Interest Paid : $",format(totalInterestPaid, '.2f'))
print("Total Principle Paid : $",format(totalPrinciplePaid, '.2f'))
print("Total Amount Paid : $",format(totalPayment, '.2f'))
print('--' * 50)

# Student details
print('Sivaranjani Prabasankar ', end="")
print('A20436206')
print(datetime.datetime.now())
print('ITMD-571 : ', end = '')
print('Lab-3')
print('**' * 50)
