import datetime

# Sivaranjani A20436206
# 10th June 2019
# ITMD-571 Lab-1

# local variable declarations
i = 0
itemCount = 0
appName = ''
# declare variable as a float type to accumulate total charges
totalCost = 0.0
costPerKW = 0.0
annualUsage = 0.0
annualCost = 0.0
average = 0.0
variance = 0.0
stdDev = 0.0
sumKW = 0.0

print('**' * 50)
itemCount = input('Please enter the no.of. appliances:')
varKW = []

while int(i) < int(itemCount):
    appName = input('Please enter the appliance name:')
    costPerKW = input('Please enter the cost per KW - hr of the appliance (in cents):')
    sumKW = sumKW + float(costPerKW)
    varKW.append(float(costPerKW))
    annualUsage = input('Please enter the annual usage (in KW - hr):')
    # Calculate cost
    annualCost = '%.2f' % (float(costPerKW) * float(annualUsage))
    print('Annual cost for appliance ', appName, 'is $', annualCost)
    i = i + 1
    totalCost = float(totalCost) + float(annualCost)

# Analytical computation over appliance data
print(sumKW, "Sum")
average = float('%.4f' % (sumKW / float(itemCount)))
i = 0
# Calculating Variance
while int(i) < int(itemCount):
    variance = float(((variance + (average - varKW[i]) ** 2) / float(itemCount)))
    i = i + 1

stdDev = variance ** .5
totalCost = '%.2f' % totalCost
print('--' * 50)
print("Yearly Usage details")
print('--' * 50)
print('Total cost of all appliances is $', totalCost)
print('Average Total cost of all appliances $', format(average, '.4f'))
print('Variance of Total cost of all appliances (with 4 decimals) is $', format(variance, '.4f'))
print('Variance of Total cost of all appliances (with 6 decimals) is $', format(variance, '.6f'))
print('StdDev of Total cost of all appliances is $', format(stdDev, '.4f'))

print('--' * 50)
# Student details
print('Sivaranjani Prabasankar ', end="")
print('A20436206')
print(datetime.datetime.now())
print('ITMD-571 : ', end="")
print('Lab-1')
print('**' * 50)
