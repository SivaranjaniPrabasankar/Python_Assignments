import datetime
import random

# Sivaranjani A20436206
# 30th June 2019
# ITMD-571 Lab-4 Game

# Compare function
def compare(arg1, arg2):
    if arg1 == arg2:
        print("Random Number : ", arg1, "User Number : ", arg2, 'Matched')
        return 'Matched'
    else:
        print("Random Number : ", arg1, "User Number : ", arg2, 'NOT Matched')
        return 'NOT Matched'


# Variable declaration
randomList = [1, 3, 5]
comparisonResult = ['', '', '']
fireBall = -1
tickets = 1
# Getting user choice
print('--' * 20, "\n Pick 3 Game \n", '--' * 20)
tickets = input('Please enter number of tickets to purchase:')
tickets = int(tickets)
fireBallTicket = -1
while int(fireBallTicket) != 0 and int(fireBallTicket) != 1:
    fireBallTicket = int(input('Please press \n 1 to play with wildcard \n 0 to play without wildcard:'))

for tktcount in range(tickets):
    lifeline = 0
    userList = [-1, -1, -1]
    print('--' * 10, " Attempt :", tktcount+1, '--' * 10)
    # Getting user input
    while userList[0] < 0 or userList[0] > 9:
        userList[0] = int(input('Please enter 1st number (Should be between 0 and 9) :'))
    while userList[1] <= userList[0] or userList[1] > 9:
        userList[1] = int(input('Please enter 2nd number (Should be between 0 and 9 And greater than first number) :'))
    while userList[1] >= userList[2] or userList[2] > 9:
        userList[2] = int(input('Please enter 3rd number (Should be between 0 and 9 And greater than above numbers):'))

    # randomList = sorted(random.sample(range(0, 10), 3))
    if fireBallTicket:
        fireBall = 5
        # fireBall = random.sample(range(0, 10), 1)
        #fireBall = int(fireBall[0])
    for count in range(len(randomList)):
        comparisonResult[count] = compare(randomList[count], userList[count])
        if (comparisonResult[count] == 'NOT Matched') and (lifeline == 0) and fireBall != -1:
            print("Using Wildcard Number ", fireBall)
            comparisonResult[count] = compare(randomList[count], fireBall)
            lifeline = int(lifeline) + 1

    # Game Result Display
    if comparisonResult.__contains__('NOT Matched'):
        print("Sorry !!! Better luck next time")
    elif lifeline == 1:
        print("Congratulations !!! Wild card got you luck !!! You won $50")
    else:
        print("Congratulations !!! You won $100")

    tktcount = tktcount + 1
    print('**' * 25)

# Student details
print('Sivaranjani Prabasankar ', end="")
print('A20436206')
print(datetime.datetime.now())
print('ITMD-571 : ', end="")
print('Lab-4')
print('**' * 50)
