import datetime

# Sivaranjani A20436206
# 17th June 2019
# ITMD-571 Lab-2 BMI Calculation

# local variable declarations
choice = 0
category = ''
# declare variable as a float type to calculate BMI
height = 0.0
weight = 0.0
BMI = 0.0

print('**' * 50)
print('--' * 20, "\nBMI: Body Mass Index for Adults \n", '--' * 20)
choice = int(input('Please enter your choice \n 1. Calculate BMI in US Standards ( using Feet/Inches & Pounds ) '
                   '\n 2. Calculate BMI in UK Standards ( using Meters & Kilograms )'))
# Calculation of BMI in US Standard

if choice == 1:
    height = float(input('Please enter Height in inches'))
    weight = float(input('Please enter weight in Pounds'))
    BMI = (weight / (height * height)) * 703

# Calculation of BMI in UK Standard
elif choice == 2:
    height = float(input('Please enter Height in Meters'))
    weight = float(input('Please enter weight in Kilograms'))
    BMI = weight / (height * height)

else:
    print("Invalid Choice")

# Categorise person based on BMI
if BMI <= 0:
    print("SORRY !! Can't calculate BMI")

elif (BMI > 0) and (BMI <= 18.50):
    category = 'Underweight'

elif (BMI > 18.50)and(BMI < 25.00):
    category = 'Normal'

else:
    category = 'Over weight'

print("Your BMI is ", format(BMI, '.2f'))
print("Person is ", category)
print('--' * 50)

# Student details
print('Sivaranjani Prabasankar ', end="")
print('A20436206')
print(datetime.datetime.now())
print('ITMD-571 : ', end="")
print('Lab-2')
print('**' * 50)
